package irm.cm.swpbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwpBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
